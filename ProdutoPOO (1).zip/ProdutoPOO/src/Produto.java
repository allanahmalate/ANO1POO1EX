import java.text.DecimalFormat;
public class Produto {

	private int codigo;  
	private String nomeArtigo;
	private float preco;
	private DecimalFormat mt;

	//construtor com parametros que inicializa os atributos do produto
	//consoante os dados extraidos do ficheiro de texto
	public Produto(int c, String n, float p)
	{
		codigo = c;
		nomeArtigo = n;
		preco = p;
		mt = new DecimalFormat("###,###.00Mts");
	}

	public float getPreco(){ return preco; } 

	public String toString()
	{ 
		return "codigo: "+codigo+" Nome do artigo: "+nomeArtigo+" Preco do artigo: "+mt.format(preco);
	}

}
