import java.util.StringTokenizer;
import java.io.*;
public class TodosProdutos
{
	private int cont;  //variavel contadora de linhas percorridas

	public TodosProdutos()
	{ 
		cont = 0; 
	}

	public void lerDoFicheiro(String nf)
	{ 
		StringTokenizer str; //uma porcao de informacao a ser dividida por Str.Tokenizer
		String umaLinha="",nomeArtigo;
		int cod;
		float s = 0,preco, media;
		try
		{
			FileReader fr = new FileReader(nf);
			BufferedReader fichIn = new BufferedReader(fr);
			umaLinha = fichIn.readLine();
			while(umaLinha != null)   // ate atingir fim de ficheiro
			{
				str = new StringTokenizer(umaLinha, ";");
				cod = Integer.parseInt(str.nextToken());  //extrai o C�digo		         
				nomeArtigo = str.nextToken(); //extrai nome de artigo
				preco = Float.parseFloat(str.nextToken());
				
				Produto p = new Produto(cod, nomeArtigo, preco); //cria obj
				s += p.getPreco();            //acumula a soma dos precos
				System.out.println(p); //visualiza os dados do produto
				umaLinha = fichIn.readLine(); //passa para a linha seguinte
				cont++; //actualiza o contador de linhas percorridas
			}
			media = s/cont;
			visualizarMedia(cont,media);
			fichIn.close();
		} 
		catch (FileNotFoundException a)	{ System.out.println("Ficheiro "+nf+"nao encontrado!"); }
		catch(NumberFormatException nb) { System.out.println(nb.getMessage()); }
		catch(IOException b){ System.out.println(b.getMessage()); }
	}
	
	//metodo para visualizar a media
	public void visualizarMedia(int c, float m)
	{
	   System.out.println("Pre�o m�dio de "+c+" produtos="+m);
	}
}

