public class Executavel {

	public static void main(String[] args) {
		TodosProdutos tp = new TodosProdutos();
		tp.lerDoFicheiro("Produtos.txt");
	}
}
